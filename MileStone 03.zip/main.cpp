#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;
struct School { //school struct includes name,address,city,state,country, and a pointer to the next one
    string name;
    string address;
    string city;
    string state;
    string country;
    School* left=nullptr;
    School* right=nullptr;

};

class BinarySearchTree {
private:
    School* root;
    School* insertSchool(School* root, School school) //insert
    {

        if (root == nullptr) //if our root is null
        {
            return new School(school.name, school.address, school.city, school.state,school.country); //add it to the tree
        }
        if (school.name < root->name ) //if root is bigger than what we insert
        {
            root->left = insertSchool(root->left,school); // go left
        }
        else // if root smaller than what we insert
        {
            root->right = insertSchool(root->right,school); //go right
        }
        return root;
    }

    School* successor(School* current){ //finds the successor if there are two children
        current = current->right;

        while (current != nullptr && current->left != nullptr) {
            current = current->left;
        }
        return current;
    }

    School* deletes(School*& root, string target)
    {
        if (root == nullptr) //if its empty or we dont find it
        {
            cout<<"Tree is empty!" << endl;
            return root;
        }

        else if (target < root->name) //traverse left
        {
            deletes(root->left, target);
        }
        else if (target > root->name) //traverse right
        {
            deletes(root->right, target);
        }
        else {
            // Cases when node has 0 children
        if (root->left == nullptr && root->right == nullptr) {
            root = NULL;
            return root;
        }
            //root has only right child
            else if (root->left == nullptr) {
                School* temp = root->right;
                delete root;
                return temp;
            }

        // the node has only left child
        else if (root->right == nullptr) {
            School* temp = root->left;
            delete root;
            return temp;
        }

        // When deleting node with both children
        School* success = successor(root);
        root->name = success->name;
        root->right = deletes(root->right, success->name);
        }
        return root;
    }

    School* find(School* root, string name)
    {
        if (root == nullptr || root->name == name) //if the root is empty or its found
        {
            return root;
        }
        else if (name < root->name) //if its smaller go left
        {
            return find(root->left, name);
        }
        else //bigger go right
        {
            return find(root->right, name);
        }
    }

    void preorderTraversalHelper(School* root) const //traverse in preorder
    {
        if (root == nullptr)
        {
            return;
        }
        cout << root->name << "->";
        preorderTraversalHelper(root->left);
        preorderTraversalHelper(root->right);
    }

    void inorderTraversalHelper(School* root) const //traverse in order
    {
        if (root == nullptr)
        {
            return;
        }

        preorderTraversalHelper(root->left);
        cout << root->name << "->";
        preorderTraversalHelper(root->right);
    }

    void postorderTraversalHelper(School* root) const
    {
        if (root == nullptr)
        {
            return;
        }
        postorderTraversalHelper(root->left);
        postorderTraversalHelper(root->right);
        cout << root->name << "->";
    }



public:
    BinarySearchTree() : root(nullptr) {} //root will start as null
    void insert(School school) //uses the node to insert the data into the tree
    {
        root = insertSchool(root, school);
    }

    void findByName(string name) //finds name and takes a string
    {
        School* temp = find(root, name);
        if (temp!=nullptr) {
            cout << "FOUND: " << endl; //print it out with its data
            cout << temp->name << "," << temp->address << "," << temp->city << "," << temp->state << "," << temp->country << endl;
        }
        else {
            cout << "No such name!" << endl;
        }
    }

    void deleteByName(string name) //deletes a name and takes a string
    {
        deletes(root,name);
    }

    void preorderTraversal() const { //travels pre order
        if (root == nullptr)
        {
            std::cout << "Empty Tree";
            return;
        }
        std::cout << "Preorder traversal: " << std::endl;
        preorderTraversalHelper(root);
        std::cout << std::endl;
    }

    void inorderTraversal() const { //travels in order
        if (root == nullptr)
        {
            std::cout << "Empty Tree";
            return;
        }
        std::cout << "Inorder traversal: " << std::endl;
        inorderTraversalHelper(root);
        std::cout << std::endl;
    }

    void postorderTraversal() //travels post order
    {
        if (root == nullptr)
        {
            std::cout << "Empty Tree";
            return;
        }
        std::cout << "Postorder traversal: " << std::endl;
        postorderTraversalHelper(root);
        std::cout << std::endl;
    }
};

static vector<vector<string>> readCSV(const string& filename, School& school,int column) { //reads the file
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
    }

    school.name = data[column][0]; //will make the school name be from what column number they chose
    school.address = data[column][1]; //will make the school address be from what column number they chose
    school.city = data[column][2];//will make the school city be from what column number they chose
    school.state = data[column][3];//will make the school state be from what column number they chose
    school.country = data[column][4]; //will make the school county be from what column number they chose

    file.close(); //close and return data
    return data;
}

int main() {
    School school;
    BinarySearchTree tree;
    School schoolarr1; //make 3 different structs for the list
    School schoolarr2;
    School schoolarr3;


    readCSV("SchoolList.csv", schoolarr1, 1); //takes from the 1st column
    readCSV("SchoolList.csv", schoolarr2, 2); //takes from the 2nd
    readCSV("SchoolList.csv", schoolarr3, 3); //takes from the 3rd

    //tree:
    //                KELLAR PRIMARY SCHOOL
    //             /                        \
    //            V                          V
    //  FRANKLIN PRIMARY SCHOOL        PLEASANT VALLEY MIDDLE SCHOOL

    tree.deleteByName("S"); //check tree is empty
    tree.findByName("s");
    tree.insert(schoolarr1); //insert the nodes
    tree.insert(schoolarr2);
    tree.insert(schoolarr3);
    tree.findByName("S"); // check if "S" is in the tree
    tree.deleteByName("S");


    tree.inorderTraversal(); //test the orders
    tree.postorderTraversal();
    tree.preorderTraversal();


    cout << endl;
    tree.findByName("PLEASANT VALLEY MIDDLE SCHOOL"); //test if name is there

    cout<<""<<endl;

    tree.deleteByName("PLEASANT VALLEY MIDDLE SCHOOL"); //delete a node
    tree.inorderTraversal(); //check if it all still works after deleting
    tree.preorderTraversal();
    tree.postorderTraversal();


}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.