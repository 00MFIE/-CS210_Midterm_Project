#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

struct School { //school struct includes name,address,city,state,country, and a pointer to the next one
    string name;
    string address;
    string city;
    string state;
    string country;
};

class SchoolHashTable {

    private:
    School *stack; //table
    int TableSize; //size

    int hashFunction(string name) { //gives us hash index
        int hash = 0;
        for (char ch : name) {
            hash += ch;
        }
        return hash % TableSize;
    }

    public:

    SchoolHashTable(int size=8) { //default construct
        TableSize = size;
        stack = new School[TableSize];
    }
    ~SchoolHashTable() { //deconstruct
        delete[] stack;
    }

    void insert(School school) {
        School* SchoolNode = new School(school.name, school.address, school.city, school.state, school.country);
        int index = hashFunction(school.name); //find index

        while (stack[index].name.empty() != true) { //case where there is a value already there
            index++; //go to next index
            if (index > TableSize) { //loop back around
                index = 0; //start at zero
            }
            if (index == hashFunction(school.name)) { //if there is no spot left and we loop back
                resize(); //resize
                index = hashFunction(school.name); //try it again
            }
        }

        stack[index] = *SchoolNode; //add node to table
    }

    void deleteByName(string name) {
        int index = hashFunction(name); //get index
        while (stack[index].name != name) { //if it isn't there
            index++; //go to next spot
            if (index > TableSize) { //if we reach the end
                index = 0; //start at the start
            }
            if (index == hashFunction(name)) {
                break;
            }
        }

        if (stack[index].name == name) { //safety check
            stack[index].name.clear(); //clear at the index
        }
        else {
            cout<<"No such name exist in the table"<<endl;
        }

    }

    void findByName(string name) {
        int index = hashFunction(name); //get index
        while (stack[index].name != name) { //if it isn't there
            index++; //go to next spot
            if (index > TableSize) { //if we reach the end
                index = 0; //start at the start
            }
            if (index == hashFunction(name)) { //if we loop back it is not there
                break; //break out from the loop
            }
        }

        if (stack[index].name == name) { //safety check
            cout <<"Name: "<<stack[index].name << endl; //display it
            cout <<"address: "<<stack[index].address << endl;
            cout <<"city: "<<stack[index].city << endl;
            cout <<"state: "<<stack[index].state << endl;
            cout <<"country: "<<stack[index].country << endl;
        }
        else {
            cout<<"No such name exist in the table"<<endl;
        }

    }

    void display() {

        for (int i = 0; i < TableSize; i++)
        {
            cout << "Hash Table Spot: " << i <<" "<< stack[i].name << endl;
        }

    }

    void resize() { //resize table if its too small for new data

        int newSize = TableSize * 2;
        School *newStack = new School[newSize];
        for (int i = 0; i < TableSize; i++) {
            newStack[i] = stack[i];
        }
        stack = newStack;
        TableSize = newSize;
        delete[] newStack;
    }

};

static vector<vector<string>> readCSV(const string& filename, School& school,int column) { //reads the file
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
    }

    school.name = data[column][0]; //will make the school name be from what column number they chose
    school.address = data[column][1]; //will make the school address be from what column number they chose
    school.city = data[column][2];//will make the school city be from what column number they chose
    school.state = data[column][3];//will make the school state be from what column number they chose
    school.country = data[column][4]; //will make the school county be from what column number they chose

    file.close(); //close and return data
    return data;
}
// TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
int main() {
    School school;
    SchoolHashTable HashTable;
    School schoolarr1; //make 3 different structs for the list
    School schoolarr2;
    School schoolarr3;

    readCSV("SchoolList.csv", schoolarr1, 1); //takes from the 1st column
    readCSV("SchoolList.csv", schoolarr2, 2); //takes from the 2nd
    readCSV("SchoolList.csv", schoolarr3, 3); //takes from the 3rd

    HashTable.insert(schoolarr1);
    HashTable.insert(schoolarr2);
    HashTable.insert(schoolarr3);
    HashTable.insert(schoolarr1); // same school but will move somewhere else in the table
    HashTable.deleteByName("KELLAR PRIMARY SCHOOL"); //deletes 1 of the schools
    HashTable.findByName("DELIMITER PRIMARY SCHOOL"); //find name that is not there
    HashTable.display(); //display the table
}

// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.