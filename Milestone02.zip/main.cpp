#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;


struct School { //school struct includes name,address,city,state,country, and a pointer to the next one
    string name;
    string address;
    string city;
    string state;
    string country;
    School* next;
};

class SchoolList
{
    School* head = nullptr; //first school in the list will be null if nothing is added

public:
    void insertFirst(School school) { //will be added in the list first position
        School* SchoolNode = new School(school.name, school.address, school.city, school.state, school.country);
        //makes the schoolNode have the information of the schools: name,address,city,state, and county

        if (head == nullptr) {
            head = SchoolNode;
        }

        else {
            SchoolNode->next = head; //the school being added next pointer will equal the head
            head = SchoolNode; //the school will equal the head being put first in the list
        }

    }
    void insertLast(School school) {
        School* SchoolNode = new School(school.name, school.address, school.city, school.state, school.country);
        //makes the schoolNode have the information of the schools: name,address,city,state, and county

        if (head == nullptr) {
            head = SchoolNode;
        }
        else {
            School* temp = head;
            while (temp->next != nullptr) //will travel to list until its at the last postion
            {
                temp = temp->next;
            }
            temp->next = SchoolNode; //adds the new school to the end of the list
        }

    }
    void deleteByName(string name) {
        School* current = head; //current pointer
        School* prev = nullptr; //previous pointer

        if (current == nullptr) {
            cout<<"List is empty!" << endl;
            return;
        }

        while (current != nullptr) {
            if (current->name == name) { //will go through the list until the names match
                break;
            }
            prev = current;
            current = current->next;
        }
        if(current==nullptr) {
            cout<<"The Name is not present in the list!"<<endl;
        }
        else if (head->name==name){ //if head is being deleted
            School* temp = head;
            head = head->next;
            delete temp;
        }
        else { //if anything else is being deleted
            prev->next = current->next;
        }


    }
    void findByName(string name) {
        School* temp = head;

        if (temp == nullptr) {
            cout<<"List is empty!"<<endl;
            return;
        }
        while (temp != nullptr){ //go through the list
            if (temp->name == name) { //if the school name is found print its information and return
                cout << temp->name << "," << temp->address << "," << temp->city << "," << temp->state << "," << temp->country << endl;
                return;
            }
            temp = temp->next;
        }
        if(temp==nullptr) {
            cout<<"The Name is not present in the list!"<<endl;
        }
    }

    void display() {
        School* temp = head;
        while (temp != nullptr) { //go through the list and print the school and information
            cout << temp->name << "," << temp->address << "," << temp->city << "," << temp->state << "," << temp->country << endl;
            temp = temp->next; //go to the next school
        }
    }

};

static vector<vector<string>> readCSV(const string& filename, School& school,int column) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
    }

    school.name = data[column][0]; //will make the school name be from what column number they chose
    school.address = data[column][1]; //will make the school address be from what column number they chose
    school.city = data[column][2];//will make the school city be from what column number they chose
    school.state = data[column][3];//will make the school state be from what column number they chose
    school.country = data[column][4]; //will make the school county be from what column number they chose

    file.close(); //close and return data
    return data;
}

int main() {
    SchoolList list;
    School schoolarr1; //make 3 different structs for the list
    School schoolarr2;
    School schoolarr3;


    readCSV("SchoolList.csv", schoolarr1, 1); //takes from the 1st column
    readCSV("SchoolList.csv", schoolarr2, 2); //takes from the 2nd
    readCSV("SchoolList.csv", schoolarr3, 3); //takes from the 3rd
    list.insertLast(schoolarr1); //inserts it last into the list
    list.insertLast(schoolarr2); //inserts it last into the list
    list.insertFirst(schoolarr3); //inserts it first into the list
    list.display(); //display current list
    list.findByName("PLEASANT VALLEY MIDDLE SCHOOL"); //find "PLEASANT VALLEY MIDDLE SCHOOL"
    list.deleteByName("PLEASANT VALLEY MIDDLE SCHOOL"); //delete "PLEASANT VALLEY MIDDLE SCHOOL"
    list.insertLast(schoolarr3); //inserts it back into the list
    list.display(); //display current list again

}

// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.