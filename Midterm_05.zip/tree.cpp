#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Timer.h"

using namespace std;
struct School { //school struct includes name,address,city,state,country, and a pointer to the next one
    string name;
    string address;
    string city;
    string state;
    string country;
    School* left=nullptr;
    School* right=nullptr;

};

class BinarySearchTree {
private:
    School* root;
    School* insertSchool(School* root, School school) //insert
    {

        if (root == nullptr) //if our root is null
        {
            return new School(school.name, school.address, school.city, school.state); //add it to the tree
        }
        if (school.name < root->name ) //if root is bigger than what we insert
        {
            root->left = insertSchool(root->left,school); // go left
        }
        else // if root smaller than what we insert
        {
            root->right = insertSchool(root->right,school); //go right
        }
        return root;
    }

    School* successor(School* current){ //finds the successor if there are two children
        current = current->right;

        while (current != nullptr && current->left != nullptr) {
            current = current->left;
        }
        return current;
    }

    School* deletes(School*& root, string target)
    {
        if (root == nullptr) //if its empty or we dont find it
        {
            cout<<"Tree is empty!" << endl;
            return root;
        }

        else if (target < root->name) //traverse left
        {
            deletes(root->left, target);
        }
        else if (target > root->name) //traverse right
        {
            deletes(root->right, target);
        }
        else {
            // Cases when node has 0 children
        if (root->left == nullptr && root->right == nullptr) {
            root = nullptr;
            return root;
        }
            //root has only right child
            else if (root->left == nullptr) {
                School* temp = root->right;
                delete root;
                return temp;
            }

        // the node has only left child
        else if (root->right == nullptr) {
            School* temp = root->left;
            delete root;
            return temp;
        }

        // When deleting node with both children
        School* success = successor(root);
        root->name = success->name;
        root->right = deletes(root->right, success->name);
        }
        return root;
    }

    School* find(School* root, string name)
    {
        if (root == nullptr || root->name == name) //if the root is empty or its found
        {
            return root;
        }
        else if (name < root->name) //if its smaller go left
        {
            return find(root->left, name);
        }
        else //bigger go right
        {
            return find(root->right, name);
        }
    }

    void preorderTraversalHelper(School* root) const //traverse in preorder
    {
        if (root == nullptr)
        {
            return;
        }
        cout << root->name << "->";
        preorderTraversalHelper(root->left);
        preorderTraversalHelper(root->right);
    }

    void inorderTraversalHelper(School* root) const //traverse in order
    {
        if (root == nullptr)
        {
            return;
        }

        preorderTraversalHelper(root->left);
        cout << root->name << "->";
        preorderTraversalHelper(root->right);
    }

    void postorderTraversalHelper(School* root) const
    {
        if (root == nullptr)
        {
            return;
        }
        postorderTraversalHelper(root->left);
        postorderTraversalHelper(root->right);
        cout << root->name << "->";
    }



public:
    BinarySearchTree() : root(nullptr) {} //root will start as null
    void insert(School school) //uses the node to insert the data into the tree
    {
        root = insertSchool(root, school);
    }

    void findByName(string name) //finds name and takes a string
    {
        School* temp = find(root, name);
        if (temp!=nullptr) {
            cout << "FOUND: " << endl; //print it out with its data
            cout << temp->name << "," << temp->address << "," << temp->city << "," << temp->state << endl;
        }
        else {
            cout << "No such name!" << endl;
        }
    }

    void deleteByName(string name) //deletes a name and takes a string
    {
        deletes(root,name);
    }

    void preorderTraversal() const { //travels pre order
        if (root == nullptr)
        {
            std::cout << "Empty Tree";
            return;
        }
        std::cout << "Preorder traversal: " << std::endl;
        preorderTraversalHelper(root);
        std::cout << std::endl;
    }

    void inorderTraversal() const { //travels in order
        if (root == nullptr)
        {
            std::cout << "Empty Tree";
            return;
        }
        std::cout << "Inorder traversal: " << std::endl;
        inorderTraversalHelper(root);
        std::cout << std::endl;
    }

    void postorderTraversal() //travels post order
    {
        if (root == nullptr)
        {
            std::cout << "Empty Tree";
            return;
        }
        std::cout << "Postorder traversal: " << std::endl;
        postorderTraversalHelper(root);
        std::cout << std::endl;
    }
};

static vector<vector<string>> readCSV(const string& filename, School& school,int n, string csv) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    BinarySearchTree tree;
    Timer t;

    string s = csv;
    ofstream outFile(s);

    outFile << "Number of elements:, time (microseconds):\n";

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
    }
    //add schools
    t.get_time();
    for (int i = 1; i < n; i++) {
        school.name = data[i][0];
        school.address = data[i][1];
        school.city = data[i][2];
        school.state = data[i][3];
        tree.insert(school);
    }
    double elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Adding To List\n";

    //find school
    t.get_time();
    string searchFor = school.name;
    tree.findByName(searchFor);
    elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Finding in list\n";

    //delete schools
    t.get_time();
    for (int i=n; i >= 0; i--) {
       school.name = data[i][0];
       string name = school.name;
        tree.deleteByName(name);
   }
   elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Removing From List\n";

    outFile.close();
    cout << "Timings saved to " << s << endl;


    file.close(); //close and return data
    return data;
}

int main() {

    srand((unsigned)time(0));
    School schoolarr1;

    //Illinois schools
    int n = 7424;
    readCSV("Illinois_Schools.csv", schoolarr1, n, "TimeForIllinois2.csv");;

    //USA schools
    long long m = 164464;
    readCSV("USA_Schools.csv", schoolarr1, m, "TimeForUSA2.csv");

}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.