#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include  "Timer.h"

using namespace std;

struct School { //school struct includes name,address,city,state,country, and a pointer to the next one
    string name;
    string address;
    string city;
    string state;
    string country;
};

class SchoolHashTable {

    private:
    School *stack; //table
    int TableSize; //size

    int hashFunction(string name) { //gives us hash index
        int hash = 0;
        for (char ch : name) {
            hash += ch;
        }
        return hash % TableSize;
    }

    public:

    SchoolHashTable(int size=170000) { //default construct
        TableSize = size;
        stack = new School[TableSize];
    }
    ~SchoolHashTable() { //deconstruct
        delete[] stack;
    }

    void insert(School school) {
        School* SchoolNode = new School(school.name, school.address, school.city, school.state);
        int index = hashFunction(school.name); //find index

        while (stack[index].name.empty() != true) { //case where there is a value already there
            index++; //go to next index
            if (index > TableSize) { //loop back around
                index = 0; //start at zero
            }
            if (index == hashFunction(school.name)) { //if there is no spot left and we loop back
                resize(); //resize
                index = hashFunction(school.name); //try it again
            }
        }

        stack[index] = *SchoolNode; //add node to table
    }

    void deleteByName(string name) {
        int index = hashFunction(name); //get index
        while (stack[index].name != name) { //if it isn't there
            index++; //go to next spot
            if (index > TableSize) { //if we reach the end
                index = 0; //start at the start
            }
            if (index == hashFunction(name)) {
                break;
            }
        }

        if (stack[index].name == name) { //safety check
            stack[index].name.clear(); //clear at the index
        }
        else {
            cout<<"No such name exist in the table"<<endl;
        }

    }

    void findByName(string name) {
        int index = hashFunction(name); //get index
        while (stack[index].name != name) { //if it isn't there
            index++; //go to next spot
            if (index > TableSize) { //if we reach the end
                index = 0; //start at the start
            }
            if (index == hashFunction(name)) { //if we loop back it is not there
                break; //break out from the loop
            }
        }

        if (stack[index].name == name) { //safety check
            cout <<"Name: "<<stack[index].name << endl; //display it
            cout <<"address: "<<stack[index].address << endl;
            cout <<"city: "<<stack[index].city << endl;
            cout <<"state: "<<stack[index].state << endl;
        }
        else {
            cout<<"No such name exist in the table"<<endl;
        }

    }

    void display() {

        for (int i = 0; i < TableSize; i++)
        {
            cout << "Hash Table Spot: " << i <<" "<< stack[i].name << endl;
        }

    }

    void resize() { //resize table if its too small for new data

        int newSize = TableSize * 2;
        School *newStack = new School[newSize];
        for (int i = 0; i < TableSize; i++) {
            newStack[i] = stack[i];
        }
        stack = newStack;
        TableSize = newSize;
        delete[] newStack;
    }

};

static vector<vector<string>> readCSV(const string& filename, School& school,int n, string csv) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    SchoolHashTable tabel;
    Timer t;

    string s = csv;
    ofstream outFile(s);

    outFile << "Number of elements:, time (microseconds):\n";

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
    }
    //add schools
    t.get_time();
    for (int i = 1; i < n; i++) {
        school.name = data[i][0];
        school.address = data[i][1];
        school.city = data[i][2];
        school.state = data[i][3];
        tabel.insert(school);
    }
    double elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Adding To List\n";

    //find school
    t.get_time();
    string searchFor = school.name;
    tabel.findByName(searchFor);
    elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Finding in list\n";

    //delete schools
    t.get_time();
    for (int i=1; i < n; i++) {
        school.name = data[i][0];
        string name = school.name;
        tabel.deleteByName(name);
    }
    elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Removing From List\n";

    outFile.close();
    cout << "Timings saved to " << s << endl;


    file.close(); //close and return data
    return data;
}
// TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
int main() {
    srand((unsigned)time(0));

    School schoolarr1;

    //Illinois schools
    int n = 7424;
    readCSV("Illinois_Schools.csv", schoolarr1, n, "TimeForIllinois3.csv");;

    //USA schools
    long long m = 164464;

    readCSV("USA_Schools.csv", schoolarr1, m, "TimeForUSA3.csv");

}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.