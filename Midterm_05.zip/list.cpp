#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include  "Timer.h"

using namespace std;

struct School { //school struct includes name,address,city,state,country, and a pointer to the next one
    string name;
    string address;
    string city;
    string state;
    string country;
    School* next;
};

class SchoolList
{
    School* head = nullptr; //first school in the list will be null if nothing is added

public:
    void insertFirst(School school) { //will be added in the list first position
        School* SchoolNode = new School(school.name, school.address, school.city, school.state);
        //makes the schoolNode have the information of the schools: name,address,city,state, and county

        if (head == nullptr) {
            head = SchoolNode;
        }

        else {
            SchoolNode->next = head; //the school being added next pointer will equal the head
            head = SchoolNode; //the school will equal the head being put first in the list
        }

    }
    void insertLast(School school) {
        School* SchoolNode = new School(school.name, school.address, school.city, school.state);
        //makes the schoolNode have the information of the schools: name,address,city,state, and county

        if (head == nullptr) {
            head = SchoolNode;
        }
        else {
            School* temp = head;
            while (temp->next != nullptr) //will travel to list until its at the last postion
            {
                temp = temp->next;
            }
            temp->next = SchoolNode; //adds the new school to the end of the list
        }

    }
    void deleteByName(string name) {
        School* current = head; //current pointer
        School* prev = nullptr; //previous pointer

        if (current == nullptr) {
            cout<<"List is empty!" << endl;
            return;
        }

        while (current != nullptr) {
            if (current->name == name) { //will go through the list until the names match
                break;
            }
            prev = current;
            current = current->next;
        }
        if(current==nullptr) {
            cout<<"The Name is not present in the list!"<<endl;
        }
        else if (head->name==name){ //if head is being deleted
            School* temp = head;
            head = head->next;
            delete temp;
        }
        else { //if anything else is being deleted
            prev->next = current->next;
        }


    }
    void findByName(string name) {
        School* temp = head;

        if (temp == nullptr) {
            cout<<"List is empty!"<<endl;
            return;
        }
        while (temp != nullptr){ //go through the list
            if (temp->name == name) { //if the school name is found print its information and return
                cout << temp->name << "," << temp->address << "," << temp->city << "," << temp->state << endl;
                return;
            }
            temp = temp->next;
        }
        if(temp==nullptr) {
            cout<<"The Name is not present in the list!"<<endl;
        }
    }

    void display() {
        School* temp = head;
        while (temp != nullptr) { //go through the list and print the school and information
            cout << temp->name << "," << temp->address << "," << temp->city << "," << temp->state << endl;
            temp = temp->next; //go to the next school
        }
    }

};

static vector<vector<string>> readCSV(const string& filename, School& school,int n, string csv) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    SchoolList list;
    Timer t;

    string s = csv;
    ofstream outFile(s);

    outFile << "Number of elements:, time (microseconds):\n";

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }

    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
    }
    //add schools
    t.get_time();
    for (int i = 1; i < n; i++) {
        school.name = data[i][0];
        school.address = data[i][1];
        school.city = data[i][2];
        school.state = data[i][3];

        list.insertFirst(school);
    }
    double elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Adding To List\n";

    //find school
    t.get_time();
    string searchFor = school.name;
    list.findByName(searchFor);
    elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Finding in list\n";

    //delete schools
    t.get_time();
    for (int i=1; i < n; i++) {
        school.name = data[i][0];
        string name = school.name;
        list.deleteByName(name);
    }
    elapsedTime = t.get_time();
    outFile << n << "," << elapsedTime << "," << "Removing From List\n";

    outFile.close();
    cout << "Timings saved to " << s << endl;


    file.close(); //close and return data
    return data;
}


int main() {
    srand((unsigned)time(0));

    School schoolarr1;

    //Illinois schools
   int n = 7424;
    readCSV("Illinois_Schools.csv", schoolarr1, n, "TimeForIllinois.csv");;

    //USA schools
    long long m = 164464;

    readCSV("USA_Schools.csv", schoolarr1, m, "TimeForUSA.csv");

}